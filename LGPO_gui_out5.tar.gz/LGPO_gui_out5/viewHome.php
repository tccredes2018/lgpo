<!DOCTYPE html>
<!---->
<!---->
<!--   ESTA PAGINA ENCONTRA-SE ATUALMENTE OBSOLETA   -->
<!--   VERSÃO MAIS ATUAL: viewHomeBootstrap.php      -->
<!---->
<!---->
<html>
<head>
    <title>Linux Group Policy</title>
    <meta charset="utf-8">
    <meta name="author" content="Gustavo Braz; Jacson Fagundes; Lucas Luz; Maicon Souza; Rebeca Yonara">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1,">
    <meta name="description" content="Modo gráfico da Linux Group Policy">
    <link rel="icon" href="img/pato_minimal_no-eyes.png" type="image/x-icon">
    <!-- FOLHAS DE ESTILOS -->
    <link rel="stylesheet" href="css/mapa-do-estilo.css">
    <script src="js/jquery-2.0.3.min.js"></script>
</head>

<body>

    <div id="div-tittle_LGPO">
        <p>LINUX GROUP POLICY</p>
    </div>

<!-- BOTOES DE NAVEGAÇÃO--> 
    <div id="div-main">
        <form id="form-navigation">
            <input type="button" value="&#8592;" onClick="history.go(-1)" class="botoes-de-navegacao"><!--VOLTAR-->
            <input type="button" value="&#8594;" onCLick="history.forward()" class="botoes-de-navegacao"><!--PRÓXIMO-->
            <input type="button" value="&#8634;" onClick="history.go(0)" class="botoes-de-navegacao"><!--RECARREGAR-->
        </form>
        
        <nav class="TREEVIEW">
        <input type="checkbox" id="tree-root" name="root"
               value="root" checked>
            <label for="tree-root"><img src="img/pato_minimal_no-eyes.png" class="img-tree">ETEC EMBU</label>
            <ul class="treeview-ul-geral-class">
            <li class="treeview-li-world-begin-class">
                <input type="checkbox" id="tree-world-1-1" name="root"
               value="root" checked>
                <label for="tree-world-1-1"><img src="img/icons/baseline_mail_black_48dp.png" class="img-tree">SECRETARIA</label>
                <ul class="treeview-li-world-proletariado-class">
                    <li><p>MAQ 1</p></li>
                    <li><p>MAQ 2</p></li>
                    <li><p>MAQ 3</p></li>
                    <li><p>MAQ 4</p></li>
                    <li><p>MAQ 5</p></li>
                </ul>
            </li>
            <li class="treeview-li-world-begin-class">
                <input type="checkbox" id="tree-world-2-1" name="root"
               value="root" checked>
                <label for="tree-world-2-1"><img src="img/icons/baseline_home_black_48dp.png" class="img-tree">DIRETORIA</label>
                <ul class="treeview-li-world-proletariado-class">
                    <li><p>MAQ 1</p></li>
                    <li><p>MAQ 2</p></li>
                </ul>
            </li>
            <li class="treeview-li-world-begin-class">
                <input type="checkbox" id="tree-world-3-1" name="root"
               value="root" checked>
                <label for="tree-world-3-1"><img src="img/icons/baseline_info_black_48dp.png" class="img-tree">LABORATORIOS</label>
                <ul class="treeview-li-world-proletariado-class">
                    <li><p>LAB 1</p></li>
                    <li><p>LAB 2</p></li>
                    <li><p>LAB 3</p></li>
                    <li><p>LAB 4</p></li>
                </ul>
            </li>
            </ul>
        </nav>
        


<!-- DASHBOARD -->



        <div class="DESCRIPTION">
            <iframe src="Gráfico_HTML.html" width="100%" height="600px"></iframe>
        </div>



<!--DEDICADO AO CLIQUE DIREITO-->



        <form class="rightclickmenu">
            <input type="button" value="Gerenciar usuários" class="rightclickobject" onclick="window.open('http://botao1darightclick.com')">
            <input type="button" value="Gerenciar usuários" class="rightclickobject" onclick="window.open('http://botao2darightclick.com')">
            <input type="button" value="OPCAO 3" class="rightclickobject" onclick="window.open('http://botao3darightclick.com')">
            <input type="button" value="OPCAO 4" class="rightclickobject" onclick="window.open('http://botao4darightclick.com')">
        </form>

        <script type="text/javascript">
            window.addEventListener('contextmenu', function(e) {
                $('.rightclickmenu').css({
                    "margin-left": e.clientX,
                    "margin-top": e.clientY
                }).show();
                $('.nada').click(function(){
                    alert("olá mundo");
                    e.preventDefault();
                    window.location.href = 'cadastrousuario.html';
                    //$('#modal').show();
                });
                e.preventDefault();
                window.addEventListener('click', function(){
                $('.rightclickmenu').hide();
                });
            });
        </script>
        
    </div>

</body>

</html>
<!DOCTYPE html>
<html>
    <head>
        <title>LGPO:: DASHBOARD</title>
        <meta charset="utf-8">
        <meta name="author" content="Gustavo Braz; Jacson Fagundes; Lucas Luz; Maicon Souza; Rebeca Yonara">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1,">
        <meta name="description" content="Modo gráfico da Linux Group Policy">
        <link rel="icon" href="img/pato_minimal_no-eyes.png" type="image/x-icon">
        <!-- FOLHAS DE ESTILOS -->
        <link rel="stylesheet" href="css/lgpoStyle.css"><!--substituto do mapadoestilo.css(inutilizado)-->
        <link rel="stylesheet" href="BOOTSTRAP/css/bootstrap.min.css">
        <!-- javascript links -->
        <script src="js/jquery-2.0.3.min.js"></script>
        <script src="BOOTSTRAP/js/bootstrap.min.js"></script>
    </head>
    
    <body>
        <div class="container">
            
            <div class="row"><!-- LINHA LINUX GROUP POLICY -->
                <div class="col">
                    <h4 id="lgpoStyle-titulo">LINUX GROUP POLICY</h4>
                </div>
            </div><!--end da div da linha Linux Group POlicy-->

            <div class="row"><!-- DIV DA LINHA DOS BOTÕES DE NAVEGAÇÃO -->
                <div class="col align-self-start"><!-- COLUNA UNICA DOS BOTÕES DE NAVEGAÇÃO -->
                    <input type="button" value="&#8592;" onClick="history.go(-1)" class="lgpoStyle-botoesDeNavegacao"><!--VOLTAR-->
                    <input type="button" value="&#8594;" onCLick="history.forward()" class="lgpoStyle-botoesDeNavegacao"><!--PRÓXIMO-->
                    <input type="button" value="&#8634;" onClick="history.go(0)" class="lgpoStyle-botoesDeNavegacao"><!--RECARREGAR-->
                </div>
            </div><!--end da div da linha dos botoes de navegação-->
        

            <div class="row"> <!-- LINHA DA TREEVIEW E DA DASHBOARD -->
                <div class="col"> <!-- COLUNA DA TREEVIEW -->
                    <div class="container float-left">
                        <P style="font-weight: bold;">TREEVIEW</p>
                        <p>item</p>
                        <p>item</p>
                        <p>item</p>
                        <p>item</p>
                        <p>item</p>
                        <p>item</p>
                        <p>item</p>
                    </div><!--end da div container float-left-->
                </div><!--end da div da coluna da treeview-->

                <div class="col"> <!-- COLUNA DA DASHBOARD -->
                    <div class="container float-right">
                        <P style="text-align: center; font-weight: bold;">DASHBOARD</p>
                        
                        <div class="embed-responsive embed-responsive-4by3"> <!-- DIV DO IFRAME DA DASHBOARD -->
                            <iframe class="embed-responsive-item" src="Dashboard/dash-linhas.html"></iframe>
                        </div>

                        <nav aria-label="Page navigation example"> <!-- NAV-BAR DA DASHBOARD -->
                            <ul class="pagination justify-content-center">
                                <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                <li class="page-item"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item"><a class="page-link" href="#">Next</a></li>
                            </ul>
                        </nav><!--end da nav-bar da dashboard-->
                    </div><!--end da div container da dashboard-->
                </div><!--end da div da coluna da dashboard-->
            </div><!--end da div da linha da treeview e da dashboard-->
        </div><!--end da div container principal-->
    </body>
</html>
<?php

# CONEXAO CASA
$conexao = ldap_connect('localhost');

#CONEXAO ROTEADA PELO ALCATEL
#$conexao = ldap_connect('192.168.43.20');

$server = 'dc=linuxgpo,dc=server';
$rootdn = 'cn=admin,'.$server;
$rootpw = 'Ldap@123';

$ou = $_POST['nomeNovaOULDAP'];

ldap_set_option($conexao, LDAP_OPT_PROTOCOL_VERSION, 3);
ldap_set_option($conexao, LDAP_OPT_REFERRALS, 0);

$registro['objectclass'][0] = 'organizationalUnit';
$registro['ou'] = $ou;


if (ldap_bind($conexao, $rootdn, $rootpw)) {
    ldap_add($conexao, "ou=$ou,$server", $registro);
    echo '1';
    #$filtro = '(uid=jacson)';
    #ldap_search($conexao,'dc=linuxgpo, dc=server' ,$filtro);
} else {
    echo '0';
}

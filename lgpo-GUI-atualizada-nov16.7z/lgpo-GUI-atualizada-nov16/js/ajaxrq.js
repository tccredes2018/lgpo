$(document).ready(function () {

    $('#usuarioLDAP').submit(function () {

        $.ajax({

            url: 'ldap/ldapUsuario.php',
            method: 'POST',
            data: $('#usuarioLDAP').serialize(),

            success: function (dados) {
                if (dados == '1') {
                    sweetAlert('Atenção!', 'Usuário inserido no servidor com sucesso!', 'success');
                    $('#usuarioLDAP').each(function () {
                        this.reset();
                    });
                    $('#cadastroModal').modal('toggle');
                } else {
                    sweetAlert('Atenção!', 'Erro! Verifique as informações e tente novamente.', 'error');
                }
            },

            beforeSend: function () {
                swal({
                    title: 'Atenção!',
                    text: 'Carregando...',
                    type: 'warning',
                    showConfirmButton: false
                });
            },

            error: function () {
                sweetAlert('Atenção!', 'Erro! Tente novamente mais tarde.', 'error');
            }

        });

        return false;

    });

    $('#OULDAP').submit(function () {

        $.ajax({

            url: 'ldap/ldapOU.php',
            method: 'POST',
            data: $('#OULDAP').serialize(),

            success: function (dados) {
                if (dados == '1') {
                    sweetAlert('Atenção!', 'Unidade Organizacional inserida no servidor com sucesso!', 'success');
                    $('#OULDAP').each(function () {
                        this.reset();
                    });
                    $('#novaOUModal').modal('toggle');
                } else {
                    sweetAlert('Atenção!', 'Erro! Verifique as informações e tente novamente.', 'error');
                }
            },

            beforeSend: function () {
                swal({
                    title: 'Atenção!',
                    text: 'Carregando...',
                    type: 'warning',
                    showConfirmButton: false
                });
            },

            error: function () {
                sweetAlert('Atenção!', 'Erro! Tente novamente mais tarde.', 'error');
            }

        });

        return false;

    });

});
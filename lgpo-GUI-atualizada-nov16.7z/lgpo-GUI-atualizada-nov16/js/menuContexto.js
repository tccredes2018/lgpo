var menu = document.querySelectorAll(".menu");
var painel = document.getElementById('arvoreLdap');
var filetree = document.getElementById('arvoreArquivos');

if (document.addEventListener) {
  painel.addEventListener('contextmenu', function(e) {
    menu[0].style.display = 'block';
    menu[0].style.marginLeft = e.clientX + 'px';
    menu[0].style.marginTop = e.clientY + 'px';
    e.preventDefault();
    
  }, false); 

  filetree.addEventListener('contextmenu', function(e) {
    menu[1].style.display = 'block';
    menu[1].style.marginLeft = e.clientX + 'px';
    menu[1].style.marginTop = e.clientY + 'px';
    e.preventDefault();  
  }, false);

} else {
    painel.attachEvent('oncontextmenu', function() {
    menu[0].style.display = 'block';
    menu[0].style.marginLeft = e.clientX + 'px';
    menu[0].style.marginTop = e.clientY + 'px';
    window.event.returnValue = false;
  }); 

  filetree.attachEvent('oncontextmenu', function() {
    menu[1].style.display = 'block';
    menu[1].style.marginLeft = e.clientX + 'px';
    menu[1].style.marginTop = e.clientY + 'px';
    window.event.returnValue = false;
  });
}

document.addEventListener('click', function(e){
  menu[0].style.display = 'none';
  menu[1].style.display = 'none';
});

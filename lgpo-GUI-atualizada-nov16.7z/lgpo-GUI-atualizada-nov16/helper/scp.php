<?php

echo passthru('bash scp.sh');
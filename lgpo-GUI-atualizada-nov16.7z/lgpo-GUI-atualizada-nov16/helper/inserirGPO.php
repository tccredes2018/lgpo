<?php

$gpo = $_POST['GPO'];
$custom = $_POST['CUSTOM'];

if(copy('../'.$gpo,'../gpo/linuxgpo.server/Usuarios/'.$custom)){
    #sleep(1);
    #chmod('../'.$gpo,0777);
    if($output = shell_exec("./gpobuild.sh '../$gpo'")){
        echo $output;
    }
} else {
    echo 0;
}

<?php

function listarDiretorio($caminho)
{
    if ($handle = opendir($caminho))
    {
        echo '<ul>';
        $queue = array();
        while (false !== ($arquivo = readdir($handle)))
        {
            if (is_dir($caminho.$arquivo) && $arquivo != '.' && $arquivo !='..')
                listarSubDiretorio($arquivo, $caminho, $queue);
            else if ($arquivo != '.' && $arquivo !='..')
                $queue[] = $arquivo;
        }

        exibir($queue, $caminho);
        echo '</ul>';
    }
}

function exibir($queue, $caminho)
{
    foreach ($queue as $arquivo)
    {
        listarArquivo($arquivo, $caminho);
    }
}

function listarArquivo($arquivo, $caminho)
{
    echo '<li class="gpo" onclick="infoGPO('."'".$caminho.$arquivo."'".');">'.$arquivo.'</li>';
}

function listarSubDiretorio($dir, $caminho)
{
    echo '<li><span class="galho">'.$dir.'</span><ul class="ramo">';
    listarDiretorio($caminho.$dir.'/');
    echo '</ul></li>';
}
<!-- MODAL CADASTRO -->
<div class="modal fade" id="cadastroModal" tabindex="-1" role="dialog" aria-labelledby="cadastroLDAPModal" aria-hidden="true">

    <div class="modal-dialog" role="document">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title" id="cadastroLDAPModal">ADICIONAR UM USUÁRIO À BASE DE DADOS LDAP</h5>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                </button>

            </div>

            <div class="modal-body">

                <div class="container">

                    <form id="usuarioLDAP">
                        <!-- FORMULÁRIO DE PREENCHIMENTO PARA ADCIONAR USUÁRIOS A BASE DE DADOS LDAP -->

                        <div class="row">

                            <div class="col">

                                <label for="nomeCadastroUsuariosLDAP">Nome:</label>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col">

                                <input type="text" class="form-control" id="nomeCadastroUsuariosLDAP" name="nomeCadastroUsuariosLDAP" placeholder="Primeiro nome">

                            </div>

                        </div>

                        <div class="row">

                            <div class="col">

                                <label for="sobrenomeCadastroUsuariosLDAP" class="lgpoStyle-titulo">Sobrenome:</label>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col">

                                <input type="text" class="form-control" id="sobrenomeCadastroUsuariosLDAP" name="sobrenomeCadastroUsuariosLDAP" placeholder="Sobrenome">

                            </div>

                        </div>

                        <div class="row">

                            <div class="col">

                                <label for="nomeDeUsuarioCadastroUsuariosLDAP" class="lgpoStyle-titulo">Nome de usuário:</label>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col">

                                <input type="text" class="form-control" id="nomeDeUsuarioCadastroUsuariosLDAP" name="nomeDeUsuarioCadastroUsuariosLDAP" placeholder="Nome de usuário">

                            </div>

                        </div>

                        <div class="row">

                            <div class="col">

                                <label for="departamentoUsuarioCadastroUsuariosLDAP" class="lgpoStyle-titulo">Departamento:</label>

                            </div>

                        </div>

                        <div class="row">

                                <!-- <input type="text" class="form-control" id="departamentoUsuarioCadastroUsuariosLDAP" name="departamentoUsuarioCadastroUsuariosLDAP" placeholder="Departamento do usuário"> -->
                                <div class="col">
                                  <select class="form-control" name="departamentoUsuarioCadastroUsuariosLDAP" id="departamentoUsuarioCadastroUsuariosLDAP">
                                    <option value="Usuarios">Usuários</option>
                                    <option value="Grupos">Grupos</option>
                                    <option value="Computadores">Computadores</option>
                                    <option value="Idmap">IdMap</option>
                                  </select>
                                </div>

                        </div>

                        <div class="row">

                            <div class="col">

                                <label for="passwordCadastroUsuariosLDAP" class="lgpoStyle-titulo">Senha:</label>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col">

                                <input type="password" class="form-control" id="passwordCadastroUsuariosLDAP" name="passwordCadastroUsuariosLDAP" placeholder="Insira a senha do usuário">

                            </div>

                        </div>

                        <ul class="nav justify-content-end lgpoStyle-titulo">

                            <!-- NAV PARA POSICIONAMENTO ADEQAUDO DOS BOTÕES E INTERAÇÃO COM O FORMULÁRIO -->
                            <li class="nav-item">

                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                            </li>

                            <li class="nav-item lgpoStyle-tituloComMarginLeft">

                                <button type="submit" class="btn btn-primary">Confirmar</button>

                            </li>

                        </ul><!-- end of NAV PARA POSICIONAMENTO ADEQAUDO DOS BOTÕES E INTERAÇÃO COM O FORMULÁRIO -->

                    </form> <!-- end of FORMULÁRIO DE PREENCHIMENTO PARA ADCIONAR USUÁRIOS A BASE DE DADOS LDAP -->

                </div>

            </div>

        </div>

    </div>

</div>
  <!-- FIM DE MODAL CADASTRO -->
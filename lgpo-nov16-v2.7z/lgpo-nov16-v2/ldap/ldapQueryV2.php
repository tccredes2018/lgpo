<?php
    # CONEXAO CASA
    $conexao = ldap_connect('localhost');

    #CONEXAO ROTEADA PELO ALCATEL
    #$conexao = ldap_connect('192.168.43.20');

    $server = 'dc=linuxgpo,dc=server';
    $rootdn = 'cn=admin,'.$server;
    $rootpw = 'ldap@123';
    $domain = 'linuxgpo.server';

    ldap_set_option($conexao, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($conexao, LDAP_OPT_REFERRALS, 0);

    if (ldap_bind($conexao, $rootdn, $rootpw)) {
        $lista = ldap_list($conexao, $server, 'ou=*');
        $info = ldap_get_entries($conexao, $lista);

        echo '<li><span class="galho">'.$domain.'</span>';

        for ($i = 0; $i < $info['count']; $i++) {
            echo '<ul class="ramo">';

            echo '<li><span class="galho">'.$info[$i]['ou'][0].'</span>';

            echo '<ul class="ramo">';

            $usuarios = ldap_list($conexao, 'ou='.$info[$i]['ou'][0].','.$server, 'uid=*');
            $saida = ldap_get_entries($conexao, $usuarios);

            for ($c = 0; $c < $saida['count']; $c++) {
                echo '<li>'.$saida[$c]['uid'][0].'</li>';
            }

            echo '</ul>';
            echo '</li>';
            echo '</ul>';
        }

        echo '</li>'; # li que fecha a treeview
    }

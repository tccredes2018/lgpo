<?php

function arvorePHP()
{
    # CONEXAO CASA
    $conexao = ldap_connect('localhost');

    #CONEXAO ROTEADA PELO ALCATEL
    #$conexao = ldap_connect('192.168.43.20');

    #dados do servidor LDAP.
    $server = 'dc=linuxgpo,dc=server';
    $rootdn = 'cn=admin,'.$server;
    $rootpw = 'ldap@123';
    $domain = 'linuxgpo.server';

    # opções necessárias para o funcionamento.
    ldap_set_option($conexao, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($conexao, LDAP_OPT_REFERRALS, 0);

    # se a autenticação for concluida...
    if (ldap_bind($conexao, $rootdn, $rootpw)) {

        # fazemos uma query buscando todas as OU's.
        $lista = ldap_list($conexao, $server, 'ou=*');

        # pegamos os registros
        $info = ldap_get_entries($conexao, $lista);

        # galho (dropdown da treeview)
        echo '<li><span class="galho">'.$domain.'</span>'."\n";

        # ramo (conteudo deste galho)
        echo '<ul class="ramo">'."\n";

        # enquanto houve registros vindos da query...
        for ($i = 0; $i < $info['count']; $i++) {

            # outro galho, porém, com o nome da OU
            echo '<li><span class="galho ou">'.$info[$i]['ou'][0].'</span>'."\n";

            # query dentro da OU buscando por usuários
            $usuarios = ldap_list($conexao, 'ou='.$info[$i]['ou'][0].','.$server, 'uid=*');

            # registros
            $saida = ldap_get_entries($conexao, $usuarios);

            # se houver algum usuário dentro da OU
            if ($saida['count'] > 0) {

                # ramo que sera usado como conteúdo da OU na treeview
                echo '<ul class="ramo">'."\n";

                # enquanto houver usuários na OU
                for ($c = 0; $c < $saida['count']; $c++) {

                    #vamos exibilos como dados da OU
                    echo '<li class="usuario">'.$saida[$c]['uid'][0].'</li>'."\n";
                }

                echo '</ul>'."\n"; # fechamento do conteúdo da OU
            }


            echo '</li>'."\n"; #fechamento da Ou
        }

        echo '</ul>'."\n"; # fechamento do conteudo da treeview

        echo '</li>'; # li que fecha a treeview
    }
}

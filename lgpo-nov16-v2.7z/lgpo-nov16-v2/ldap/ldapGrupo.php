<?php

# CONEXAO CASA
$conexao = ldap_connect('localhost');

#CONEXAO ROTEADA PELO ALCATEL
#$conexao = ldap_connect('192.168.43.20');

$server = 'dc=linuxgpo,dc=server';
$rootdn = 'cn=admin,'.$server;
$rootpw = 'ldap@123';

ldap_set_option($conexao, LDAP_OPT_PROTOCOL_VERSION, 3);
ldap_set_option($conexao, LDAP_OPT_REFERRALS, 0);

$nome = $_POST["nomeCadastroUsuariosLDAP"];
$senha = $_POST["passwordCadastroUsuariosLDAP"];
$unidade = $_POST['departamentoUsuarioCadastroUsuariosLDAP'];

$registro['objectclass'][0] = 'inetOrgPerson';
$registro['objectclass'][1] = 'posixAccount';
$registro['objectclass'][2] = 'shadowAccount';
$registro['cn'] = $nome;
$registro['sn'] = $nome;
$registro['userPassword'] = $senha;
$registro['loginShell'] = '/bin/bash';
$registro['uidNumber'] = '2000';
$registro['gidNumber'] = '2000';
$registro['homeDirectory'] = "/home/$nome";


if (ldap_bind($conexao, $rootdn, $rootpw)) {
    ldap_add($conexao, "uid=$nome,ou=$unidade,$server", $registro);
    echo '1';
    #$filtro = '(uid=jacson)';
    #ldap_search($conexao,'dc=linuxgpo, dc=server' ,$filtro);
} else {
    echo '0';
}

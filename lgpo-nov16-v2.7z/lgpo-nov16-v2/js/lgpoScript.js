//FUNÇÕES UTILIZADAS PARA ALTERAÇÃO DO "src" DO IFRAME DA DASHBOARD

var caminho;

function AlteraPropriedadeUm(){
var iframe = document.getElementById('grafico_iframe');
iframe.src = 'Dashboard/dash-linhas.html';
}

function AlteraPropriedadeDois(){
var iframe = document.getElementById('grafico_iframe');
iframe.src = 'Dashboard/dash-bar.html';
}

function AlteraPropriedadeTres(){
var iframe = document.getElementById('grafico_iframe');
iframe.src = 'Dashboard/dash-doughnut.html';
}
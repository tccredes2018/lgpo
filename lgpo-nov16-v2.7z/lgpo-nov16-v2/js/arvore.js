var path;

var toggler = document.getElementsByClassName("galho");

var arvoreLdap = document.getElementById('arvoreLdap');
var arvoreArquivos = document.getElementById('arvoreArquivos');

var tag_ldap = arvoreLdap.getElementsByTagName('span');
var tag_arquivos = arvoreArquivos.getElementsByTagName('span');

var class_arquivos = arvoreArquivos.getElementsByClassName('gpo');

function infoGPO(caminho){
    //alert(window.location.href);
    //alert(caminho);
    path = caminho;
    $.ajax({

        url: 'helper/read.php',
        method: 'POST',
        dataType: 'json',
        data: 'GPO='+window.location.href + caminho,

        success: function(data){
            console.log('dados: ' + data);
            $('#nomeGPO').text(data[0]);
            $('#descGPO').text(data[1]);
            $('#autorGPO').text(data[2]);
            $('#versaoGPO').text(data[3]);
            $('#alteracaoGPO').text(data[4]);
        },

        error: function(e){
            console.log('deu erro man.'+ e.responseText);
        }

    });
}

function selecionarItemArquivos(){

    for(i =0; i < tag_arquivos.length; i++){

        tag_arquivos[i].style.backgroundColor = '#fff';
        tag_arquivos[i].style.padding='0px';
        tag_arquivos[i].style.color='#000';
        tag_arquivos[i].style.fontWeight='100';
    
        tag_arquivos[i].addEventListener('click', function(e){
    
            selecionarItemArquivos();
            this.style.background='#00f';
            this.style.padding='5px';
            this.style.color='#fff';
            this.style.fontWeight='bolder';
        });
        
    }

}

function selecionarItemLdap(){

    for(i =0; i < tag_ldap.length; i++){

        tag_ldap[i].style.backgroundColor = '#fff';
        tag_ldap[i].style.padding='0px';
        tag_ldap[i].style.color='#000';
        tag_ldap[i].style.fontWeight='100';
    
        tag_ldap[i].addEventListener('click', function(e){
    
            selecionarItemLdap();
            this.style.background='#00f';
            this.style.padding='5px';
            this.style.color='#fff';
            this.style.fontWeight='bolder';
        });
        
    }

}

selecionarItemLdap();
selecionarItemArquivos();

var i;

for (i = 0; i < toggler.length; i++) {
    toggler[i].addEventListener("click", function () {
        this.parentElement.querySelector(".ramo").classList.toggle("active");
        this.classList.toggle("galho-down");
    });
}

$(document).ready(function(){

    $('#form-gpo').submit(function(){

        $.ajax({
  
          url: 'helper/inserirGPO.php',
          method: 'POST',
          data: 'GPO='+path+'&CUSTOM='+$('#nomegpo').val(),
  
          success: function(dados){
            alert(dados);
          },
  
          error: function(e){
            console.log('deu erro man.'+ e.responseText);
          }
  
        });
        return false;
      });

});
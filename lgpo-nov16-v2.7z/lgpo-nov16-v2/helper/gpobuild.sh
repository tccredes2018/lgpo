#!/bin/bash

if [ -f "$1" ]; then

	GPO=$1
	CWD=`pwd`
	echo $GPO >> loggpo.txt

	. $GPO

	
	. $CWD'/template.desktop' > $CWD'/'$NOME_PROGRAMA.desktop
	. $CWD'/template.policy' > $CWD'/'$NOME_PROGRAMA.policy

	#/usr/bin/scp $CWD'/'$NOME_PROGRAMA.desktop root@192.168.43.35:/root
	#/usr/bin/scp $CWD'/'$NOME_PROGRAMA.policy root@192.168.43.35:/root

	/usr/bin/scp $CWD'/'$NOME_PROGRAMA.desktop root@192.168.43.242:/root
	/usr/bin/scp $CWD'/'$NOME_PROGRAMA.policy root@192.168.43.242:/root

	/usr/bin/scp $CWD'/'$NOME_PROGRAMA.desktop root@192.168.43.200:/root
	/usr/bin/scp $CWD'/'$NOME_PROGRAMA.policy root@192.168.43.200:/root

	#ssh "root@192.168.43. 'mv -v /root/$NOME_PROGRAMA.policy /usr/share/polkit-1/actions/org.$NOME_PROGRAMA-as-root.policy'"
	#ssh "root@192.168.43.35 'mv -v /root/$NOME_PROGRAMA.desktop /usr/share/applications/$NOME_PROGRAMA.desktop'"
	ssh "root@192.168.43.200 'mv -v /root/$NOME_PROGRAMA.policy /usr/share/polkit-1/actions/org.$NOME_PROGRAMA-as-root.policy'"
	ssh "root@192.168.43.200 'mv -v /root/$NOME_PROGRAMA.desktop /usr/share/applications/$NOME_PROGRAMA.desktop'"
	ssh "root@192.168.43.242 'mv -v /root/$NOME_PROGRAMA.policy /usr/share/polkit-1/actions/org.$NOME_PROGRAMA-as-root.policy'"
	ssh "root@192.168.43.242 'mv -v /root/$NOME_PROGRAMA.desktop /usr/share/applications/$NOME_PROGRAMA.desktop'"
	
else
	echo 'GPO inválida.'
fi

#!/bin/bash

/usr/bin/scp /home/debian/Documentos/comandos.txt root@192.168.43.242:/root



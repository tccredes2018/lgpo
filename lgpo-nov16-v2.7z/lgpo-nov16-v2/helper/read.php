<?php

#$file = explode("\n", file_get_contents('bloquear-painei-configuracoes.lgpo'));

$dados = array();

$file = explode("\n", file_get_contents($_POST['GPO']));

for ($i = 0; $i < 5; $i ++)
{
	$dados[$i] = str_replace("'","",substr($file[$i+2],strpos($file[$i+2],"'"),strlen($file[$i+2])));
}

echo json_encode($dados);
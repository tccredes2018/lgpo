<!DOCTYPE html>
<html>

<head>

  <title>LGPO:: DASHBOARD</title>

  <meta charset="utf-8" />
  <meta name="author" content="Gustavo Braz; Jacson Fagundes; Lucas Luz; Maicon Souza; Rebeca Yonara" />
  <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1," />
  <meta name="description" content="Modo gráfico da Linux Group Policy" />

  <link rel="icon" href="img/polyHatsune_recorte.png" type="image/x-icon" />
  <link rel="stylesheet" href="css/bootstrap.min.css" />
  <link rel="stylesheet" href="css/lgpoStyle.css" />
  <link rel="stylesheet" href="css/arvore.css" />
  <link rel="stylesheet" href="css/menu.css" />

</head>

<body class="lgpoStyle-body">
  <!--<div class="container">-->

 <?php

#IMPORTANDO O MODAL DE NOVA UNIDADE ORGANIZACIONAL
require_once 'modal/modalOU.php';

#IMPORTANDO O MODAL DE CADASTRO DE USUARIO
require_once 'modal/modalCadastro.php';

require_once 'modal/modalGPO.php';

#IMPORTANDO O MENU DE CONTEXTO
require_once 'modal/menuContexto2.php';

?>

<!-- LINHA LINUX GROUP POLICY -->
<div class="flex-row lgpoStyle-titulo">

  <div class="d-flex justify-content-center">

    <h4>LINUX GROUP POLICY</h4>

    <span class="badge badge-light height-badge lgpoStyle-backgroundBadge" style="margin-top: 5px;">LGPO</span>

  </div>

</div>


<div class="row">

  <div class="col-3 margem-para-alinhamento-nav-inicial" style="margin-left: 50px;">

    <input type="button" value="&#8592;" onClick="history.go(-1)" class="lgpoStyle-botoesDeNavegacao">

    <input type="button" value="&#8594;" onCLick="history.forward()" class="lgpoStyle-botoesDeNavegacao">

    <input type="button" value="&#8634;" onClick="history.go(0)" class="lgpoStyle-botoesDeNavegacao">
  </div>
    
  <div class="col" style="margin-right: 50px;">
      
    <input type="button" value="3" onClick="AlteraPropriedadeTres()" class="lgpoStyle-botoesDeNavegacao lgpoStyle-botoes-do-iframe">

    <input type="button" value="2" onClick="AlteraPropriedadeDois()" class="lgpoStyle-botoesDeNavegacao lgpoStyle-botoes-do-iframe">
      
    <input type="button" value="1" onClick="AlteraPropriedadeUm()" class="lgpoStyle-botoesDeNavegacao lgpoStyle-botoes-do-iframe">
      
  </div>

</div>


<div class="row lgpoStyle-linhaDaTreeeviewEDaDashboard">

  <div class="col-3 lgpoStyle-colunaTreeviewBackground">

    <div class="container float-left height-seiscentos" id="painel">

    <div class="row">

      <div class="col-12" style="height: 100%;" id="arvoreLdap">

      <div id="arvore">

          <?php require_once 'ldap/ldapQuery.php';
arvorePHP();
?>

      </div>

    </div>
    </div>

    <div class="row">
    <div class="col-12" style="height: 100%;" id="arvoreArquivos">

      <div id="filetree">

          <?php require_once 'modal/filetree.php';

# galho (dropdown da treeview)
echo '<li style="list-style: none;"><span class="galho">linuxgpo.server' . '</span>' . "\n";

# ramo (conteudo deste galho)
echo '<ul class="ramo">' . "\n";

listarDiretorio('gpo/linuxgpo.server/');

echo '</ul></li>';

?>
  </div>
      </div>

    </div>

    </div>

  </div>

  <div class="col">

    <!-- <div class="float-right"> -->

      <div class="row">

        <div class="col background-config alinhamento" style="padding-top: 15px;">
            
            <div class="container">

          <p class="font-color-family">PAINEL LGPO</p>
          <p class="font-color-family">NOME DA GPO: <span id="nomeGPO" class="font-color-family">BLOQUEAR PAINEL DE CONFIGURAÇÕES DO XFCE</span></p>
          <p class="font-color-family">DESCRIÇÃO: <span id="descGPO" class="font-color-family">ESTA GPO BLOQUEIA O ACESSO AO PAINEL DE CONFIGURAÇÕES DO XFCE, VISANDO PADRONIZAR AS WORKSTATIONS</span></p>
          <p class="font-color-family">DESENVOLVIDO POR: <span id="autorGPO" class="font-color-family">REBECA YONARA</span></p>
          <p class="font-color-family">VERSAO: <span id="versaoGPO" class="font-color-family">1.0.0</span></p>
          <p class="font-color-family">ULTIMA ALTERAÇÃO: <span id="alteracaoGPO" class="font-color-family">12/10/2018</span></p>
</div>
        </div>

        <div class="col alinhamento" style="margin-right: 50px;">

          <div class="embed-responsive embed-responsive-16by9">

            <iframe class="embed-responsive-item background-config" id="grafico_iframe" src="Dashboard/dash-linhas.html"></iframe>

          </div>

        </div>

      </div>

    </div>

  <!-- </div> -->

</div>

<!-- javascript links -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/sweetalert2.all.min.js"></script>
<script src="js/arvore.js"></script>
<script src="js/ajaxrq.js"></script>
<script src="js/menuContexto.js"></script>
<script src="js/lgpoScript.js"></script>

</body>

</html>

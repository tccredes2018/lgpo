#
limpeza de arquivos inúteis como 'viewHome.php'

que estava sem utilidade e ainda estava presente

na versão 'LGPO_gui_out23', remoção de diretórios

de testes php: '/php/gpo', alteração do nome da

pagina web principal de 'viewHomeBootstrap.php'

para 'viewHomeDef.php'
#

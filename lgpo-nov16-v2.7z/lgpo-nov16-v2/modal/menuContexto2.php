<ul class="menu">

    <li class="submenu">Novo<ul>

        <a data-toggle="modal" data-target="#cadastroModal"><li>Usuário</li></a>
        <a data-toggle="modal" data-target="#novaOUModal"><li>Unidade Organizacional</li></a>
        <a><li>Grupo</li></a>
        <a><li>Máquina</li></a>

        </ul></li>

    <a><li>Renomear</li></a>
    <a><li>Remover</li></a>
    <a><li>Detalhes</li></a>

</ul>

<ul class="menu">

<a data-toggle="modal" data-target="#GPOModal"><li>Nova gpo</li></a>
<a><li>Renomear</li></a>
<a><li>Remover</li></a>
<a><li>Detalhes</li></a>

</ul>
<!-- MODAL DE NOVA OU -->
<div class="modal fade" id="novaOUModal" tabindex="-1" role="dialog" aria-labelledby="novaOULDAPModal" aria-hidden="true">

    <div class="modal-dialog" role="document">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title" id="novaOULDAPModal">NOVA UNIDADE ORGANIZACIONAL</h5>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                </button>

            </div>

            <div class="modal-body">

                <div class="container">

                    <form id="OULDAP">

                        <!-- FORMULÁRIO DE PREENCHIMENTO PARA ADCIONAR USUÁRIOS A BASE DE DADOS LDAP -->
                        <div class="row">

                            <div class="col">

                                <label id="localDeCriacaoDaNovaOULDAP">LOCAL DE CRIAÇÃO: /itemPrimario/itemSecundário</label>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col">

                                <label for="nomeNovaOULDAP" class="lgpoStyle-titulo">Nome:</label>

                            </div>

                        </div>

                        <div class="row">

                            <div class="col">

                                <input type="text" class="form-control" id="nomeNovaOULDAP" name="nomeNovaOULDAP" placeholder="Insira o nome da nova Unidade Organizacional">

                            </div>

                        </div>

                        <ul class="nav justify-content-end lgpoStyle-titulo">

                            <!-- NAV PARA POSICIONAMENTO ADEQAUDO DOS BOTÕES E INTERAÇÃO COM O FORMULÁRIO -->
                            <li class="nav-item">

                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>

                            </li>

                            <li class="nav-item lgpoStyle-tituloComMarginLeft">

                                <button type="submit" class="btn btn-primary">Confirmar</button>
                                
                            </li>

                        </ul><!-- end of NAV PARA POSICIONAMENTO ADEQAUDO DOS BOTÕES E INTERAÇÃO COM O FORMULÁRIO -->

                    </form> <!-- end of FORMULÁRIO DE PREENCHIMENTO PARA ADCIONAR USUÁRIOS A BASE DE DADOS LDAP -->

                </div>

            </div>

        </div>

    </div>

</div>
<!-- FIM DE MODAL DE NOVA OU -->
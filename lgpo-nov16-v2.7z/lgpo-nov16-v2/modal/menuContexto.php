<ul class="rightclickmenu">

    <li>

        <button type="button" class="btn btn-primary rightclickobject" data-toggle="modal" data-target="#exampleModal">

            Gerenciar usuários
        
        </button>

    </li>

    <li>

        <button type="button" class="btn btn-primary lgpoStyle-rightClickMarginTop rightclickobject" data-toggle="modal" data-target="#exampleModal">

            Gerenciar grupos
            
        </button>

    </li>

    <li>

    <button type="button" class="btn btn-primary lgpoStyle-rightClickMarginTop rightclickobject" data-toggle="modal" data-target="#novaOUModal">

        Nova OU

    </button>

    </li>

    <li>

        <button type="button" class="btn btn-primary lgpoStyle-rightClickMarginTop rightclickobject" data-toggle="modal" data-target="#cadastroModal">

            Novo usuário

        </button>

    </li>

    <li>

        <button type="button" class="btn btn-primary lgpoStyle-rightClickMarginTop rightclickobject" data-toggle="modal" data-target="#cadastroModal">

            Remover item selecionado

        </button>

    </li>

    <li>

        <button type="button" class="btn btn-primary lgpoStyle-rightClickMarginTop rightclickobject" data-toggle="modal" data-target="#cadastroModal">

            Renomear

        </button>

    </li>

</ul>
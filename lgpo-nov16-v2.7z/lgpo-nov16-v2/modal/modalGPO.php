<!-- MODAL DE NOVA OU -->
<div class="modal fade" id="GPOModal" tabindex="1" role="dialog" aria-labelledby="GPOModal" aria-hidden="true">

    <div class="modal-dialog" role="document">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title" id="novaOULDAPModal">Selecionar política de grupo a ser aplicada</h5>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                </button>

            </div>

            <div class="modal-body">

                <p style="background: #ccc; padding: 10px; font-weight: bolder; font-size: 16px;">Selecione uma das políticas de grupo disponíveis para aplicar na Unidade Organizacional selecionada:</p>
                <div class="container" style="padding: 20px;">

                <?php require_once 'filetree.php';

                    # galho (dropdown da treeview)
                    echo '<li style="list-style: none;"><span class="galho">linuxgpo.server' . '</span>' . "\n";

                    # ramo (conteudo deste galho)
                    echo '<ul class="ramo">' . "\n";

                    listarDiretorio('gpo/default/');

                    echo '</ul></li>';

                ?>

                </div>

                <div class="modal-footer" style="background-color: #ccc;">
                
                    <div class="container">
                    
                        <form id="form-gpo" class="form-inline">
                        
                            <div class="form-group float-left">
                                <label for="nomegpo" class="mr-3">NOME DA GPO:</label>
                                <input type="text" class="form-control" name="nomegpo" id="nomegpo" placeholder="Nome da sua GPO...">
                    
                            </div>

                            <div class="form-group float-right">
                                <button class="btn btn-primary ml-2">OK</button>
                            </div>

                        </form>
                    
                    </div>
                
                </div>

            </div>

        </div>

    </div>

</div>
<!-- FIM DE MODAL DE NOVA OU -->